package com.Controller;

import com.Dao.CourseDAO;
import com.Dao.TutorDAO;
import com.Model.Tutor;
import com.Model.Courses;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/tutor")
public class TutorServlet extends HttpServlet {

    private TutorDAO tutorDAO;
    private CourseDAO courseDAO;

    public void init() {
        tutorDAO = new TutorDAO();
        courseDAO = new CourseDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String command = request.getParameter("command");
        try {
            switch (command) {
                case "insertTutor":
                    insertTutor(request, response);
                    break;
                case "editTutorProfile":
                    showEditTutorProfile(request, response);
                    break;
                case "updateTutorProfile":
                    updateTutorProfile(request, response);
                    break;
                case "listTutor":
                    showListTutor(request, response);
                    break;
                case "showTutorDetails":
                    showTutorDetails(request, response);
                    break;

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void showTutorDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int tutorID = Integer.parseInt(request.getParameter("tutorID"));
        Tutor existingTutor = tutorDAO.retrieveOneTutor(tutorID);
        List<Courses> listCourse = courseDAO.selectPrivateTutorCourse(tutorID);

        request.setAttribute("listCourse", listCourse);
        request.setAttribute("tutor", existingTutor);

        RequestDispatcher dispatcher = request.getRequestDispatcher("privateTutorDetails.jsp");
        dispatcher.forward(request, response);
    }

    private void showListTutor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        List<Tutor> listTutor = tutorDAO.retrieveAllTutor();
        request.setAttribute("listTutor", listTutor);
        RequestDispatcher dispatcher = request.getRequestDispatcher("privTutorList.jsp");
        dispatcher.forward(request, response);

    }

    private void insertTutor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        String tutorName = request.getParameter("tutorName");
        String tutorPassword = request.getParameter("tutorPassword");
        String tutorPhoneNo = request.getParameter("tutorPhoneNo");
        String tutorEmail = request.getParameter("tutorEmail");
        String tutorGender = request.getParameter("tutorGender");
        String tutorDOB = request.getParameter("tutorDOB");
        int tutorNoOfYearTeach = Integer.parseInt(request.getParameter("tutorNoOfYearTeach"));
        String tutorLocation = request.getParameter("tutorLocation");
        String tutorAddress = request.getParameter("tutorAddress");
        String tutorQualification = request.getParameter("tutorQualification");
        String tutorExperience = request.getParameter("tutorExperience");

        Tutor newtutor = new Tutor(tutorName, tutorGender, tutorDOB, tutorQualification, tutorExperience, tutorAddress, tutorLocation, tutorPhoneNo, tutorEmail, tutorPassword, tutorNoOfYearTeach);

        tutorDAO.insertTutor(newtutor);

        response.sendRedirect("index.jsp");

    }

    private void showEditTutorProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int tutorid = Integer.parseInt(request.getParameter("id"));

        Tutor tutor = tutorDAO.retrieveOneTutor(tutorid);
        RequestDispatcher dispatcher = request.getRequestDispatcher("tutorEditProfile.jsp");
        request.setAttribute("currentuser", tutor);
        dispatcher.forward(request, response);

    }

    private void updateTutorProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        PrintWriter out = response.getWriter();
        int tutorID = Integer.parseInt(request.getParameter("tutorID"));
        String tutorName = request.getParameter("tutorName");
        String tutorPassword = request.getParameter("tutorPassword");
        String tutorPhoneNo = request.getParameter("tutorPhoneNo");
        String tutorEmail = request.getParameter("tutorEmail");
        String tutorGender = request.getParameter("tutorGender");
        String tutorDOB = request.getParameter("tutorDOB");
        int tutorNoOfYearTeach = Integer.parseInt(request.getParameter("tutorNoOfYearTeach"));
        String tutorLocation = request.getParameter("tutorLocation");
        String tutorAddress = request.getParameter("tutorAddress");
        String tutorQualification = request.getParameter("tutorQualification");
        String tutorExperience = request.getParameter("tutorExperience");

        HttpSession s = request.getSession();
        Tutor tutor = (Tutor) s.getAttribute("currentUser");

        tutor.setTutorID(tutorID);
        tutor.setTutorName(tutorName);
        tutor.setTutorPassword(tutorPassword);
        tutor.setTutorPhone(tutorPhoneNo);
        tutor.setTutorEmail(tutorEmail);
        tutor.setTutorGender(tutorGender);
        tutor.setTutorDOB(tutorDOB);
        tutor.setTutorNoOfYearTeach(tutorNoOfYearTeach);
        tutor.setTutorLocation(tutorLocation);
        tutor.setTutorAddress(tutorAddress);
        tutor.setTutorQualification(tutorQualification);
        tutor.setTutorExperience(tutorExperience);

        //update database...
        boolean ans = tutorDAO.updateTutor(tutor);

        request.getRequestDispatcher("tutorProfile.jsp").include(request, response);

    }

}
