
package com.Controller;

import com.Dao.StudentDAO;

import com.Model.Student;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/student")
public class StudentServlet extends HttpServlet {

private StudentDAO studentDAO;

public void init() {
        studentDAO = new StudentDAO();
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String command = request.getParameter("command");
        try {
            switch (command) {
                case "insertStudent":
                    insertStudent(request, response);
                    break;
                case "editStudentProfile":
                    showEditStudentProfile(request, response);
                    break;
                case "updateStudentProfile":
                    updateStudentProfile(request, response);
                    break;
               
                

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response); 
    }

    private void insertStudent(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        String studentName = request.getParameter("studentName");
        String studentPassword = request.getParameter("studentPassword");
        String studentPhoneNo = request.getParameter("studentPhoneNo");
        String studentEmail = request.getParameter("studentEmail");
        String studentIC = request.getParameter("studentIC");
        
        String studentSchool = request.getParameter("studentSchool");
        String studentAddress = request.getParameter("studentAddress");
        

        Student newStudent = new Student(studentName, studentIC, studentSchool, studentPhoneNo, studentEmail, studentPassword,studentAddress);

        studentDAO.insertStudent(newStudent);
        

        response.sendRedirect("index.jsp");

    }
    private void showEditStudentProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int studentid = Integer.parseInt(request.getParameter("id"));

        Student student = studentDAO.retrieveOneStudent(studentid);
        RequestDispatcher dispatcher = request.getRequestDispatcher("studentEditProfile.jsp");
        request.setAttribute("currentuser", student);
        dispatcher.forward(request, response);

    }
    
    private void updateStudentProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        PrintWriter out = response.getWriter();
        int studentID = Integer.parseInt(request.getParameter("studentID"));
        String studentName = request.getParameter("studentName");
        String studentPassword = request.getParameter("studentPassword");
        String studentPhoneNo = request.getParameter("studentPhoneNo");
        String studentEmail = request.getParameter("studentEmail");
        String studentIC = request.getParameter("studentIC");
        String studentSchool = request.getParameter("studentSchool");
        String studentAddress = request.getParameter("studentAddress");
        


        HttpSession s = request.getSession();
        Student student = (Student) s.getAttribute("currentUser");

        student.setStudentID(studentID);
        student.setStudentName(studentName);
        student.setStudentPhoneNo(studentPhoneNo);
        student.setStudentEmail(studentEmail);
        student.setStudentPassword(studentPassword);
        student.setStudentSchool(studentSchool);
        student.setStudentAddress(studentAddress); 
        student.setStudentIC(studentIC); 
        
        //update database...
        boolean ans = studentDAO.updateStudent(student);
        
        request.getRequestDispatcher("studentProfile.jsp").include(request, response);

    }
   

}
