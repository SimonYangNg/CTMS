package com.Controller;

import com.Dao.AdminDAO;
import com.Dao.StudentDAO;
import com.Dao.TuitionDAO;
import com.Dao.TutorDAO;
import com.Model.Admin;
import java.time.format.DateTimeFormatter;
import java.time.LocalDate;
import com.Model.Student;
import com.Model.Tutor;
import com.Model.Message;
import com.Model.Tuition;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/admin")
public class AdminServlet extends HttpServlet {

    private AdminDAO adminDAO;
    private TuitionDAO tuitionDAO;
    private StudentDAO studentDAO;
    private TutorDAO tutorDAO;

    public void init() {
        adminDAO = new AdminDAO();
        tuitionDAO = new TuitionDAO();
        studentDAO = new StudentDAO();
        tutorDAO = new TutorDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String command = request.getParameter("command");
        try {
            switch (command) {
                case "insertTuition":
                    insertTuition(request, response);
                    break;
                case "login":
                    loginUser(request, response);
                    break;
                case "editAdminProfile":
                    showEditAdminProfile(request, response);
                    break;
                case "updateAdminProfile":
                    updateAdminProfile(request, response);
                    break;
                case "listTeacher":
                    showlistTeacher(request, response);
                    break;
                case "showTuitionTutorForm":
                    showTuitionTutorForm(request, response);
                case "insertTutor":
                    insertTutor(request, response);
                    break;
                case "editTutor":
                    showTuitionTutorEditForm(request, response);
                    break;
                case "updateTutor":
                    updateTutor(request, response);
                    break;
                    

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void showTuitionTutorForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher dispatcher = request.getRequestDispatcher("tuition_reg_tutor.jsp");
        dispatcher.forward(request, response);
    }
    
    
    private void insertTuition(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        String adminName = request.getParameter("adminName");
        String adminPassword = request.getParameter("adminPassword");
        String adminPhoneNo = request.getParameter("adminPhoneNo");
        String adminEmail = request.getParameter("adminEmail");

        String tuitionName = request.getParameter("tuitionName");
        String tuitionPhoneNo = request.getParameter("tuitionPhoneNo");
        String tuitionOverview = request.getParameter("tuitionOverview");
        String tuitionSpecialities = request.getParameter("tuidotionSpecialities");
        String tuitionAddress = request.getParameter("tuitionAddress");
        String tuitionLocation = request.getParameter("tuitionLocation");

        Tuition newTuition = new Tuition(tuitionName, tuitionOverview, tuitionLocation, tuitionPhoneNo, tuitionAddress, tuitionSpecialities);

        tuitionDAO.insertTuition(newTuition);
        Tuition tuition = tuitionDAO.getTuitionID();
        int tuitionID = tuition.getTuitionID();

        Admin newAdmin = new Admin(adminName, adminPassword, adminPhoneNo, adminEmail, tuitionID);

        adminDAO.insertAdmin(newAdmin);

        response.sendRedirect("index.jsp");

    }

    private void loginUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        String uname = request.getParameter("userName");
        String password = request.getParameter("userPassword");
        String role = request.getParameter("userRole");

        Admin admin = null;
        Student student = null;
        Tutor tutor = null;

        switch (role) {
            case "student":
                try {

                student = studentDAO.studentLogin(uname, password);

                if (student == null) {
                    Message msg = new Message("Invalid Details ! Try with another", "error", "alert-danger");
                    HttpSession s = request.getSession();
                    s.setAttribute("msg", msg);

                    response.sendRedirect("login.jsp");
                } else {
                    HttpSession s = request.getSession();
                    s.setAttribute("currentUser", student);
                    RequestDispatcher dispatcher = request.getRequestDispatcher("studentProfile.jsp");
                    request.setAttribute("student", student);
                    dispatcher.forward(request, response);

                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            break;
            case "tutor":
                try {

                tutor = tutorDAO.tutorLogin(uname, password);

                if (tutor == null) {
                    Message msg = new Message("Invalid Details ! Try with another", "error", "alert-danger");
                    HttpSession s = request.getSession();
                    s.setAttribute("msg", msg);

                    response.sendRedirect("login.jsp");
                } else {
                    HttpSession s = request.getSession();
                    s.setAttribute("currentUser", tutor);
                    RequestDispatcher dispatcher = request.getRequestDispatcher("tutorProfile.jsp");
                    request.setAttribute("tutor", tutor);
                    dispatcher.forward(request, response);

                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            break;
            case "institute":                 
                try {

                admin = adminDAO.adminLogin(uname, password);

                if (admin == null) {
                    Message msg = new Message("Invalid Details ! Try with another", "error", "alert-danger");
                    HttpSession s = request.getSession();
                    s.setAttribute("msg", msg);

                    response.sendRedirect("login.jsp");
                } else {
                    HttpSession s = request.getSession();
                    s.setAttribute("currentUser", admin);
                    RequestDispatcher dispatcher = request.getRequestDispatcher("adminProfile.jsp");
                    request.setAttribute("admin", admin);
                    dispatcher.forward(request, response);

                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            break;

        }

    }

    private void showEditAdminProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int adminid = Integer.parseInt(request.getParameter("id"));

        Admin admin = adminDAO.retrieveOneAdmin(adminid);
        RequestDispatcher dispatcher = request.getRequestDispatcher("adminEditProfile.jsp");
        request.setAttribute("currentuser", admin);
        dispatcher.forward(request, response);

    }

    private void updateAdminProfile(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        PrintWriter out = response.getWriter();
        int adminID = Integer.parseInt(request.getParameter("adminID"));
        String adminName = request.getParameter("adminName");
        String adminPhoneNo = request.getParameter("adminPhoneNo");
        String adminEmail = request.getParameter("adminEmail");
        String adminPassword = request.getParameter("adminPassword");
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));

        HttpSession s = request.getSession();
        Admin admin = (Admin) s.getAttribute("currentUser");

        admin.setAdminID(adminID);
        admin.setAdminName(adminName);
        admin.setAdminPhoneNo(adminPhoneNo);
        admin.setAdminEmail(adminEmail);
        admin.setAdminPassword(adminPassword);
        admin.setTuitionID(tuitionID);

        //update database...
        boolean ans = adminDAO.updateAdmin(admin);

        request.getRequestDispatcher("adminProfile.jsp").include(request, response);

    }

    private void showlistTeacher(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        List<Tutor> listTuitionTutor = tutorDAO.listTuitionTutor(tuitionID);
        request.setAttribute("listTuitionTutor", listTuitionTutor);
        RequestDispatcher dispatcher = request.getRequestDispatcher("teacherList.jsp");
        dispatcher.forward(request, response);
    }

    private void insertTutor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        String tutorName = request.getParameter("tutorName");
        
        String tutorPhoneNo = request.getParameter("tutorPhoneNo");
        String tutorEmail = request.getParameter("tutorEmail");
        String tutorGender = request.getParameter("tutorGender");
        String tutorDOB = request.getParameter("tutorDOB");
        int tutorNoOfYearTeach = Integer.parseInt(request.getParameter("tutorNoOfYearTeach"));
        String tutorQualification = request.getParameter("tutorQualification");
        String tutorExperience = request.getParameter("tutorExperience");

        Tutor newtutor = new Tutor(tutorName, tutorGender, tutorDOB, tutorQualification, tutorExperience, tutorPhoneNo, tutorEmail, tutorNoOfYearTeach);

        tutorDAO.insertTutionTutor(newtutor);
        int tutorID = tutorDAO.retrieveLatestTutorID();

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        LocalDate now = LocalDate.now();
        tutorDAO.insertTuitionTutorJoinDate(tuitionID, tutorID, dtf.format(now));

        response.sendRedirect("admin?command=listTeacher&tuitionID=" + tuitionID);

    }
    private void showTuitionTutorEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int tutorID = Integer.parseInt(request.getParameter("tutorID"));

        Tutor tutor = tutorDAO.retrieveOneTutor(tutorID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("tuition_reg_tutor.jsp");
        request.setAttribute("tutor", tutor);
        dispatcher.forward(request, response);

    }

    private void updateTutor(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        PrintWriter out = response.getWriter();
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        int tutorID = Integer.parseInt(request.getParameter("tutorID"));
        String tutorName = request.getParameter("tutorName");
        String tutorGender = request.getParameter("tutorGender");
        String tutorDOB = request.getParameter("tutorDOB");
        String tutorQualification = request.getParameter("tutorQualification");
        String tutorExperience = request.getParameter("tutorExperience");
        String tutorPhoneNo = request.getParameter("tutorPhoneNo");
        String tutorEmail = request.getParameter("tutorEmail");
        int tutorNoOfYearTeach = Integer.parseInt(request.getParameter("tutorNoOfYearTeach"));

        Tutor tutor = new Tutor();

        tutor.setTutorID(tutorID);
        tutor.setTutorName(tutorName);
        tutor.setTutorGender(tutorGender);
        tutor.setTutorDOB(tutorDOB);
        tutor.setTutorQualification(tutorQualification);
        tutor.setTutorExperience(tutorExperience);
        tutor.setTutorPhone(tutorPhoneNo);
        tutor.setTutorEmail(tutorEmail);
        tutor.setTutorNoOfYearTeach(tutorNoOfYearTeach);

        //update database...
        boolean ans = tutorDAO.updateTuitionTutor(tutor);

        response.sendRedirect("admin?command=listTeacher&tuitionID=" + tuitionID);

    }
}
