package com.Controller;

import com.Dao.ClassDAO;
import com.Dao.TutorDAO;
import com.Dao.CourseDAO;
import com.Dao.TuitionDAO;
import com.Model.Classes;
import com.Model.Tutor;
import com.Model.Courses;
import com.Model.Tuition;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/class")
public class ClassServlet extends HttpServlet {

    private CourseDAO courseDAO;
    private ClassDAO classDAO;
    private TutorDAO tutorDAO;
    private TuitionDAO tuitionDAO;

    public void init() {
        courseDAO = new CourseDAO();
        classDAO = new ClassDAO();
        tutorDAO = new TutorDAO(); 
        tuitionDAO = new TuitionDAO(); 

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String command = request.getParameter("command");
        try {
            switch (command) {
                case "listClass":
                    listClass(request, response);
                    break;
                case "addClass":
                    showNewClassForm(request, response);
                    break;
                case "insertClass":
                    insertClass(request, response);
                    break;
                case "showCourseDetails":
                    showCourseDetails(request, response);
                    break;
                case "editClass":
                    showEditClass(request, response);
                    break;
                case "updateClass":
                    updateClass(request, response);
                    break;
                case "deleteClass":
                    deleteClass(request, response);
                    break;

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);

    }

    private void listClass(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        List<Classes> listClass = classDAO.listTuitionClass(tuitionID);
       
        request.setAttribute("listTuitionClasses", listClass);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("classList.jsp");
        dispatcher.forward(request, response);
    }

    private void showNewClassForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        
        List<Courses> listCourse = courseDAO.selectTuitionCourse(tuitionID);
        request.setAttribute("listCourse", listCourse);
        
        List<Tutor> listTutor = tutorDAO.listTuitionTutor(tuitionID);
        request.setAttribute("listTutor", listTutor);

        RequestDispatcher dispatcher = request.getRequestDispatcher("classForm.jsp");
        dispatcher.forward(request, response);
    }

    private void insertClass(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        String newcourse = request.getParameter("newCourse");

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        int courseID = Integer.parseInt(request.getParameter("courseID"));
        int tutorID = Integer.parseInt(request.getParameter("tutorID"));
        int totalStudent = Integer.parseInt(request.getParameter("totalStudent"));
        String classAvail = request.getParameter("classAvailability");
        
        int duration = Integer.parseInt(request.getParameter("duration"));
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        String daysoftheweek = request.getParameter("newdaysOfTheWeek");
       Classes newClasses = new Classes(courseID,tuitionID,tutorID,totalStudent,classAvail,duration,startTime,endTime,daysoftheweek);
        classDAO.insertTuitionClass(newClasses);
        listClass(request, response);
    }
    private void showCourseDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        int courseID = Integer.parseInt(request.getParameter("courseID"));
        Courses existingCourse = courseDAO.selectOneTuitionCourse(courseID, tuitionID);
        Tuition existingInstitute = tuitionDAO.retrieveOneTuition(tuitionID);
        List<Classes> listClass = classDAO.listTuitionCourseClass(tuitionID,courseID);
        
        request.setAttribute("listClass", listClass);
        request.setAttribute("institute", existingInstitute);
        request.setAttribute("course", existingCourse);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("courseDetails.jsp");
        dispatcher.forward(request, response);

    }

    private void showEditClass(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        
        int classID = Integer.parseInt(request.getParameter("classID"));
        
        List<Courses> listCourse = courseDAO.selectTuitionCourse(tuitionID);
        request.setAttribute("listCourse", listCourse);
        
        List<Tutor> listTutor = tutorDAO.listTuitionTutor(tuitionID);
        request.setAttribute("listTutor", listTutor);
        
        Classes existingClass = classDAO.selectOneTuitionClass(classID);
        
        request.setAttribute("classes", existingClass);
        
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("classForm.jsp");
        dispatcher.forward(request, response);
        
    }

    private void updateClass(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        int classID = Integer.parseInt(request.getParameter("classID"));
        int courseID ,tutorID ;
        String classAvail,daysoftheweek ="";
        if (request.getParameter("courseID") == null) {
            courseID = Integer.parseInt(request.getParameter("oldCourseID"));
        } else {
            courseID = Integer.parseInt(request.getParameter("courseID"));
        }
        if (request.getParameter("tutorID") == null) {
            tutorID = Integer.parseInt(request.getParameter("oldTutorID"));
        } else {
            tutorID = Integer.parseInt(request.getParameter("tutorID"));
        }
        if (request.getParameter("classAvailability") == null) {
            classAvail = request.getParameter("availability");
        } else {
            classAvail = request.getParameter("classAvailability");
        }
        if (request.getParameter("newdaysOfTheWeek") == null) {
            daysoftheweek = request.getParameter("olddaysOfTheWeek");
        } else {
            daysoftheweek = request.getParameter("newdaysOfTheWeek");
        }
        
        int totalStudent = Integer.parseInt(request.getParameter("totalStudent"));
        
        int duration = Integer.parseInt(request.getParameter("duration"));
        String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");
        
       Classes updateClasses = new Classes(classID,courseID,tuitionID,tutorID,totalStudent,classAvail,duration,startTime,endTime,daysoftheweek);
        classDAO.updateTuitionClass(updateClasses);
        listClass(request, response);
        
        

    }
    private void deleteClass(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
       int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        int classID = Integer.parseInt(request.getParameter("classID"));

        classDAO.deleteTuitionClass(classID);
        listClass(request, response);
    }

}
