package com.Controller;

import com.Dao.CourseDAO;
import com.Model.Courses;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/course")
public class CourseServlet extends HttpServlet {

    private CourseDAO courseDAO;

    public void init() {
        courseDAO = new CourseDAO();

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String command = request.getParameter("command");
        try {
            switch (command) {
                case "listCourse":
                    listCourse(request, response);
                    break;
                case "listPrivateTutorCourse":
                    listPrivateTutorCourse(request, response);
                    break;
                case "addCourse":
                    showNewCourseForm(request, response);
                    break;
                case "showPrivCourseForm":
                    showPrivCourseForm(request, response);
                    break;
                case "insertCourse":
                    insertCourse(request, response);
                    break;
                case "insertPrivateTutorCourse":
                    insertPrivateTutorCourse(request, response);
                    break;
                case "editCourse":
                    showEditCourse(request, response);
                    break;
                case "updateCourse":
                    updateCourse(request, response);
                    break;
                case "deleteCourse":
                    deleteCourse(request, response);
                    break;

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);

    }

    private void listCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));

        List<Courses> listCourse = courseDAO.selectTuitionCourse(tuitionID);
        request.setAttribute("listCourse", listCourse);
        RequestDispatcher dispatcher = request.getRequestDispatcher("courseProfile.jsp");
        dispatcher.forward(request, response);

    }

    private void listPrivateTutorCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int tutorID = Integer.parseInt(request.getParameter("tutorID"));

        List<Courses> listCourse = courseDAO.selectPrivateTutorCourse(tutorID);
        request.setAttribute("listCourse", listCourse);
        RequestDispatcher dispatcher = request.getRequestDispatcher("privateTutorCourseList.jsp");
        dispatcher.forward(request, response);

    }

    private void showNewCourseForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Courses> listCourse = courseDAO.getAllCourse();
        request.setAttribute("listCourse", listCourse);

        RequestDispatcher dispatcher = request.getRequestDispatcher("courseForm.jsp");
        dispatcher.forward(request, response);
    }

    private void showPrivCourseForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Courses> listCourse = courseDAO.getAllCourse();
        request.setAttribute("listCourse", listCourse);

        RequestDispatcher dispatcher = request.getRequestDispatcher("privateTutorCourseForm.jsp");
        dispatcher.forward(request, response);
    }

    private void insertCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        Courses course = null;
        String newcourse = request.getParameter("newCourse");

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        String courseDescription = request.getParameter("courseDescription");
        double coursePrice = Double.parseDouble(request.getParameter("coursePrice"));
        if (newcourse.equals("")) {
            int courseID = Integer.parseInt(request.getParameter("courseID"));
            course = new Courses(courseID, tuitionID, courseDescription, coursePrice);

        } else {
            courseDAO.insertNewCourse(newcourse);
            Courses newCourseID = courseDAO.getNewCourseID();
            course = new Courses(newCourseID.getCourseID(), tuitionID, courseDescription, coursePrice);

        }
        courseDAO.insertCourse(course);
        listCourse(request, response);
    }

    private void insertPrivateTutorCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        Courses course = null;
        String newcourse = request.getParameter("newCourse");

        int tutorID = Integer.parseInt(request.getParameter("tutorID"));
        String courseDescription = request.getParameter("courseDescription");
        double coursePrice = Double.parseDouble(request.getParameter("coursePrice"));
        if (newcourse.equals("")) {
            int courseID = Integer.parseInt(request.getParameter("courseID"));
            course = new Courses(courseID, courseDescription,tutorID, coursePrice);

        } else {
            courseDAO.insertNewCourse(newcourse);
            Courses newCourseID = courseDAO.getNewCourseID();
            course = new Courses(newCourseID.getCourseID(), courseDescription,tutorID, coursePrice);

        }
        courseDAO.insertPrivateTutorCourse(course);
        listPrivateTutorCourse(request, response);
    }

    private void showEditCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int courseID = Integer.parseInt(request.getParameter("courseID"));
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        List<Courses> listCourse = courseDAO.getAllCourse();
        request.setAttribute("listCourse", listCourse);
        Courses existingCourse = courseDAO.selectOneTuitionCourse(courseID, tuitionID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("courseForm.jsp");
        request.setAttribute("course", existingCourse);
        dispatcher.forward(request, response);
    }

    private void updateCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int courseID = Integer.parseInt(request.getParameter("courseID"));
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        String courseDescription = request.getParameter("courseDescription");
        Double coursePrice = Double.parseDouble(request.getParameter("coursePrice"));

        Courses course = new Courses(courseID, tuitionID, courseDescription, coursePrice);
        courseDAO.updateTuitionCourse(course);
        listCourse(request, response);
    }

    private void deleteCourse(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        int courseID = Integer.parseInt(request.getParameter("courseID"));
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));

        courseDAO.deleteTuitionCourse(courseID, tuitionID);
        listCourse(request, response);
    }

}
