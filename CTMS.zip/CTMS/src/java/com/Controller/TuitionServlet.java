package com.Controller;

import com.Dao.TuitionDAO;
import com.Dao.CourseDAO;

import com.Model.Courses;
import com.Model.Tuition;
import com.Model.Tutor;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/tuition")
public class TuitionServlet extends HttpServlet {

    private TuitionDAO tuitionDAO;
    private CourseDAO courseDAO;

    public void init() {
        tuitionDAO = new TuitionDAO();
        courseDAO = new CourseDAO();

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String command = request.getParameter("command");
        try {
            switch (command) {
                case "showAllInstitute":
                    showAllInstitute(request, response);
                    break;
                case "showInstituteDetails":
                    showInstituteDetails(request, response);
                    break;
                case "showInstituteEditPage":
                    showInstituteEditPage(request, response);
                    break;
                case "updateTuition":
                    updateTuition(request, response);
                    break;

            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void showAllInstitute(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        List<Tuition> listActivity = tuitionDAO.retrieveAllInstitute();
        request.setAttribute("listInstitute", listActivity);
        RequestDispatcher dispatcher = request.getRequestDispatcher("instituteList.jsp");
        dispatcher.forward(request, response);

    }

    private void showInstituteDetails(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        Tuition existingInstitute = tuitionDAO.retrieveOneTuition(tuitionID);
        List<Courses> listCourse = courseDAO.selectTuitionCourse(tuitionID);
        
        request.setAttribute("listCourse", listCourse);
        request.setAttribute("institute", existingInstitute);
        
        RequestDispatcher dispatcher = request.getRequestDispatcher("instituteDetails.jsp");
        dispatcher.forward(request, response);

    }

    private void showInstituteEditPage(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {

        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        Tuition existingInstitute = tuitionDAO.retrieveOneTuition(tuitionID);
        RequestDispatcher dispatcher = request.getRequestDispatcher("instituteEditDetails.jsp");
        request.setAttribute("institute", existingInstitute);
        dispatcher.forward(request, response);

    }
     private void updateTuition(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        
        int tuitionID = Integer.parseInt(request.getParameter("tuitionID"));
        String tuitionName = request.getParameter("tuitionName");
        String tuitionLocation = request.getParameter("tuitionLocation");
        String tuitionAddress = request.getParameter("tuitionAddress");
        String tuitionPhoneNo = request.getParameter("tuitionPhoneNo");
        String tuitionSpecialities = request.getParameter("tuitionSpecialities");
        String tuitionOverview = request.getParameter("tuitionOverview");
        


        
        Tuition tuition = new Tuition();

        tuition.setTuitionID(tuitionID);
        tuition.setTuitionName(tuitionName);
        tuition.setTuitionLocation(tuitionLocation);
        tuition.setTuitionAddress(tuitionAddress);
        tuition.setTuitionPhoneNo(tuitionPhoneNo);
        tuition.setTuitionSpecialities(tuitionSpecialities);
        tuition.setTuitionOverview(tuitionOverview); 
         
        
        //update database...
        tuitionDAO.updateTuition(tuition);
        
        response.sendRedirect("tuition?command=showInstituteEditPage&tuitionID=" + tuitionID);

    }

}
