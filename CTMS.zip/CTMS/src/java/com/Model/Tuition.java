
package com.Model;


public class Tuition {
    private int tuitionID;
    private String tuitionName;
    private String tuitionOverview;
    private String tuitionLocation;
    private String tuitionPhoneNo;
    private String tuitionAddress;
    private String tuitionSpecialities;

    public Tuition() { }

    
    public Tuition( String tuitionName, String tuitionOverview, String tuitionLocation, String tuitionPhoneNo, String tuitionAddress, String tuitionSpecialities) {
        
        this.tuitionName = tuitionName;
        this.tuitionOverview = tuitionOverview;
        this.tuitionLocation = tuitionLocation;
        this.tuitionPhoneNo = tuitionPhoneNo;
        this.tuitionAddress = tuitionAddress;
        this.tuitionSpecialities = tuitionSpecialities;
    }
    
    

    public int getTuitionID() {
        return tuitionID;
    }

    public void setTuitionID(int tuitionID) {
        this.tuitionID = tuitionID;
    }

    public String getTuitionName() {
        return tuitionName;
    }

    public void setTuitionName(String tuitionName) {
        this.tuitionName = tuitionName;
    }

    public String getTuitionOverview() {
        return tuitionOverview;
    }

    public void setTuitionOverview(String tuitionOverview) {
        this.tuitionOverview = tuitionOverview;
    }

    public String getTuitionLocation() {
        return tuitionLocation;
    }

    public void setTuitionLocation(String tuitionLocation) {
        this.tuitionLocation = tuitionLocation;
    }

    public String getTuitionPhoneNo() {
        return tuitionPhoneNo;
    }

    public void setTuitionPhoneNo(String tuitionPhoneNo) {
        this.tuitionPhoneNo = tuitionPhoneNo;
    }

    public String getTuitionAddress() {
        return tuitionAddress;
    }

    public void setTuitionAddress(String tuitionAddress) {
        this.tuitionAddress = tuitionAddress;
    }

    public String getTuitionSpecialities() {
        return tuitionSpecialities;
    }

    public void setTuitionSpecialities(String tuitionSpecialities) {
        this.tuitionSpecialities = tuitionSpecialities;
    }
    
}
