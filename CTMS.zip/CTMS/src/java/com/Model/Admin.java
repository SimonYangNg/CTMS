
package com.Model;

public class Admin {
    private int adminID;
    private String adminName;
    private String adminPassword;
    private String adminPhoneNo;
    private String adminEmail;
    private int tuitionID;

    public Admin() {
    }

    public Admin( String adminName, String adminPassword, String adminPhoneNo, String adminEmail, int tuitionID) {
        
        this.adminName = adminName;
        this.adminPassword = adminPassword;
        this.adminPhoneNo = adminPhoneNo;
        this.adminEmail = adminEmail;
        this.tuitionID = tuitionID;
    }

    public int getAdminID() {
        return adminID;
    }

    public void setAdminID(int adminID) {
        this.adminID = adminID;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    public String getAdminPhoneNo() {
        return adminPhoneNo;
    }

    public void setAdminPhoneNo(String adminPhoneNo) {
        this.adminPhoneNo = adminPhoneNo;
    }

    public String getAdminEmail() {
        return adminEmail;
    }

    public void setAdminEmail(String adminEmail) {
        this.adminEmail = adminEmail;
    }

    public int getTuitionID() {
        return tuitionID;
    }

    public void setTuitionID(int tuitionID) {
        this.tuitionID = tuitionID;
    }
    
    
}
