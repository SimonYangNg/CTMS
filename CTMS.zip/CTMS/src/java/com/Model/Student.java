
package com.Model;

public class Student {
    private int studentID;
    private String studentName;
    private String studentIC;
    private String studentSchool;
    private String studentPhoneNo;
    private String studentEmail;
    private String studentPassword;
    private String studentAddress;

    public Student() {
    }

    public Student(String studentName, String studentIC, String studentSchool, String studentPhoneNo, String studentEmail, String studentPassword, String studentAddress) {
        this.studentName = studentName;
        this.studentIC = studentIC;
        this.studentSchool = studentSchool;
        this.studentPhoneNo = studentPhoneNo;
        this.studentEmail = studentEmail;
        this.studentPassword = studentPassword;
        this.studentAddress = studentAddress;
    }

    public int getStudentID() {
        return studentID;
    }

    public void setStudentID(int studentID) {
        this.studentID = studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getStudentIC() {
        return studentIC;
    }

    public void setStudentIC(String studentIC) {
        this.studentIC = studentIC;
    }

    public String getStudentSchool() {
        return studentSchool;
    }

    public void setStudentSchool(String studentSchool) {
        this.studentSchool = studentSchool;
    }

    public String getStudentPhoneNo() {
        return studentPhoneNo;
    }

    public void setStudentPhoneNo(String studentPhoneNo) {
        this.studentPhoneNo = studentPhoneNo;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public void setStudentEmail(String studentEmail) {
        this.studentEmail = studentEmail;
    }

    public String getStudentPassword() {
        return studentPassword;
    }

    public void setStudentPassword(String studentPassword) {
        this.studentPassword = studentPassword;
    }

    public String getStudentAddress() {
        return studentAddress;
    }

    public void setStudentAddress(String studentAddress) {
        this.studentAddress = studentAddress;
    }
    
    
}
