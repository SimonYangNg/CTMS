
package com.Model;

public class Courses {
    private int courseID;
    private String courseName;
    
//    tuition_tutor_course table
    private int tuitionID;
    private int tutorID;
    private String courseDescription;
    private double coursePrice;

    public Courses() {
    }

    public Courses(int courseID, String courseName) {
        this.courseID = courseID;
        this.courseName = courseName;
    }

    public Courses(int courseID, String courseName, int tuitionID, String courseDescription, double coursePrice) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.tuitionID = tuitionID;
        this.courseDescription = courseDescription;
        this.coursePrice = coursePrice;
    }
    public Courses(int courseID, String courseName,  String courseDescription,int tutorID, double coursePrice) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.tutorID = tutorID;
        this.courseDescription = courseDescription;
        this.coursePrice = coursePrice;
    }
    public Courses(int courseID, int tuitionID, String courseDescription, double coursePrice) {
        this.courseID = courseID;
        this.tuitionID = tuitionID;
        this.courseDescription = courseDescription;
        this.coursePrice = coursePrice;
    }
    public Courses(int courseID,  String courseDescription,int tutorID, double coursePrice) {
        this.courseID = courseID;
        this.tutorID = tutorID;
        this.courseDescription = courseDescription;
        this.coursePrice = coursePrice;
    }
    

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public int getTuitionID() {
        return tuitionID;
    }

    public void setTuitionID(int tuitionID) {
        this.tuitionID = tuitionID;
    }

    public int getTutorID() {
        return tutorID;
    }

    public void setTutorID(int tutorID) {
        this.tutorID = tutorID;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public double getCoursePrice() {
        return coursePrice;
    }

    public void setCoursePrice(double coursePrice) {
        this.coursePrice = coursePrice;
    }
    
    
}
