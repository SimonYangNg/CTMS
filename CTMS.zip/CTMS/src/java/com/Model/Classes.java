
package com.Model;

public class Classes {
    private int classID;
    private int courseID;
    private String courseName;
    private int tuitionID;
    private int tutorID;
    private String tutorName;
    private int totalStudent;
    private String availability;
    private int duration;
    private String startTime;
    private String endTime;
    private String days;

    public Classes() {
    }

    
    public Classes(int classID, int courseID, int tuitionID, int tutorID, int totalStudent, String availability, int duration, String startTime, String endTime, String days) {
        this.classID = classID;
        this.courseID = courseID;
        this.tuitionID = tuitionID;
        this.tutorID = tutorID;
        this.totalStudent = totalStudent;
        this.availability = availability;
        this.duration = duration;
        this.startTime = startTime;
        this.endTime = endTime;
        this.days = days;
    }

    public Classes(int courseID, int tuitionID, int tutorID, int totalStudent, String availability, int duration, String startTime, String endTime, String days) {
        this.courseID = courseID;
        this.tuitionID = tuitionID;
        this.tutorID = tutorID;
        this.totalStudent = totalStudent;
        this.availability = availability;
        this.duration = duration;
        this.startTime = startTime;
        this.endTime = endTime;
        this.days = days;
    }

    public Classes(int classID, int courseID, String courseName, int tuitionID, int tutorID, String tutorName, int totalStudent, String availability, int duration, String startTime, String endTime, String days) {
        this.classID = classID;
        this.courseID = courseID;
        this.courseName = courseName;
        this.tuitionID = tuitionID;
        this.tutorID = tutorID;
        this.tutorName = tutorName;
        this.totalStudent = totalStudent;
        this.availability = availability;
        this.duration = duration;
        this.startTime = startTime;
        this.endTime = endTime;
        this.days = days;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getTutorName() {
        return tutorName;
    }

    public void setTutorName(String tutorName) {
        this.tutorName = tutorName;
    }

    
    public int getClassID() {
        return classID;
    }

    public void setClassID(int classID) {
        this.classID = classID;
    }

    public int getCourseID() {
        return courseID;
    }

    public void setCourseID(int courseID) {
        this.courseID = courseID;
    }

    public int getTuitionID() {
        return tuitionID;
    }

    public void setTuitionID(int tuitionID) {
        this.tuitionID = tuitionID;
    }

    public int getTutorID() {
        return tutorID;
    }

    public void setTutorID(int tutorID) {
        this.tutorID = tutorID;
    }

    public int getTotalStudent() {
        return totalStudent;
    }

    public void setTotalStudent(int totalStudent) {
        this.totalStudent = totalStudent;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }
    
    
    
}
