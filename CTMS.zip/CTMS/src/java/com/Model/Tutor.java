
package com.Model;

public class Tutor {
    private int tutorID;
    private String tutorName;
    private String tutorGender;
    private String tutorDOB;
    private String tutorQualification;
    private String tutorExperience;
    private String tutorAddress;
    private String tutorLocation;
    private String tutorPhone;
    private String tutorEmail;
    private String tutorPassword;
    private int tutorNoOfYearTeach;

    public Tutor() {
    }

    
    public Tutor(String tutorName, String tutorGender, String tutorDOB, String tutorQualification, String tutorExperience, String tutorAddress, String tutorLocation, String tutorPhone, String tutorEmail, String tutorPassword,int tutorNoOfYearTeach) {
        this.tutorName = tutorName;
        this.tutorGender = tutorGender;
        this.tutorDOB = tutorDOB;
        this.tutorQualification = tutorQualification;
        this.tutorExperience = tutorExperience;
        this.tutorAddress = tutorAddress;
        this.tutorLocation = tutorLocation;
        this.tutorPhone = tutorPhone;
        this.tutorEmail = tutorEmail;
        this.tutorPassword = tutorPassword;
        this.tutorNoOfYearTeach = tutorNoOfYearTeach;
    }

    public Tutor( String tutorName, String tutorGender, String tutorDOB, String tutorQualification, String tutorExperience, String tutorPhone, String tutorEmail, int tutorNoOfYearTeach) {
        
        this.tutorName = tutorName;
        this.tutorGender = tutorGender;
        this.tutorDOB = tutorDOB;
        this.tutorQualification = tutorQualification;
        this.tutorExperience = tutorExperience;
        this.tutorPhone = tutorPhone;
        this.tutorEmail = tutorEmail;
        this.tutorNoOfYearTeach = tutorNoOfYearTeach;
    }

    public Tutor(int tutorID, String tutorName, String tutorGender, String tutorDOB, String tutorQualification, String tutorExperience, String tutorPhone, String tutorEmail, int tutorNoOfYearTeach) {
        this.tutorID = tutorID;
        this.tutorName = tutorName;
        this.tutorGender = tutorGender;
        this.tutorDOB = tutorDOB;
        this.tutorQualification = tutorQualification;
        this.tutorExperience = tutorExperience;
        this.tutorPhone = tutorPhone;
        this.tutorEmail = tutorEmail;
        this.tutorNoOfYearTeach = tutorNoOfYearTeach;
    }

    public Tutor(int tutorID, String tutorName, String tutorGender, String tutorDOB, String tutorQualification, String tutorExperience, String tutorAddress, String tutorLocation, String tutorPhone, String tutorEmail, int tutorNoOfYearTeach) {
        this.tutorID = tutorID;
        this.tutorName = tutorName;
        this.tutorGender = tutorGender;
        this.tutorDOB = tutorDOB;
        this.tutorQualification = tutorQualification;
        this.tutorExperience = tutorExperience;
        this.tutorAddress = tutorAddress;
        this.tutorLocation = tutorLocation;
        this.tutorPhone = tutorPhone;
        this.tutorEmail = tutorEmail;
        this.tutorNoOfYearTeach = tutorNoOfYearTeach;
    }
    

    public int getTutorID() {
        return tutorID;
    }

    public void setTutorID(int tutorID) {
        this.tutorID = tutorID;
    }

    public String getTutorName() {
        return tutorName;
    }

    public void setTutorName(String tutorName) {
        this.tutorName = tutorName;
    }

    public String getTutorGender() {
        return tutorGender;
    }

    public void setTutorGender(String tutorGender) {
        this.tutorGender = tutorGender;
    }

    public String getTutorDOB() {
        return tutorDOB;
    }

    public void setTutorDOB(String tutorDOB) {
        this.tutorDOB = tutorDOB;
    }

    public String getTutorQualification() {
        return tutorQualification;
    }

    public void setTutorQualification(String tutorQualification) {
        this.tutorQualification = tutorQualification;
    }

    public String getTutorExperience() {
        return tutorExperience;
    }

    public void setTutorExperience(String tutorExperience) {
        this.tutorExperience = tutorExperience;
    }

    public String getTutorAddress() {
        return tutorAddress;
    }

    public void setTutorAddress(String tutorAddress) {
        this.tutorAddress = tutorAddress;
    }

    public String getTutorLocation() {
        return tutorLocation;
    }

    public void setTutorLocation(String tutorLocation) {
        this.tutorLocation = tutorLocation;
    }

    public String getTutorPhone() {
        return tutorPhone;
    }

    public void setTutorPhone(String tutorPhone) {
        this.tutorPhone = tutorPhone;
    }

    public String getTutorEmail() {
        return tutorEmail;
    }

    public void setTutorEmail(String tutorEmail) {
        this.tutorEmail = tutorEmail;
    }

    public String getTutorPassword() {
        return tutorPassword;
    }

    public void setTutorPassword(String tutorPassword) {
        this.tutorPassword = tutorPassword;
    }

    public int getTutorNoOfYearTeach() {
        return tutorNoOfYearTeach;
    }

    public void setTutorNoOfYearTeach(int tutorNoOfYearTeach) {
        this.tutorNoOfYearTeach = tutorNoOfYearTeach;
    }
    
    
    
}
