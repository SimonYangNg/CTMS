package com.Dao;

import com.Model.Tuition;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TuitionDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/ctms";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";
    
    private static final String INSERT_TUITION_SQL= "INSERT INTO `tuition` (`tuitionID`, `tuitionName`, `tuitionOverview`, `tuitionLocation`, `tuitionPhoneNo`, `tuitionAddress`, tuitionSpecialities) VALUES (NULL, ?, ?, ?, ?, ?, ?)";
    private static final String GET_LAST_TUITIONID_SQL = "Select tuitionID from tuition where tuitionID = (select max(tuitionID) from tuition)";
    private static final String SELECT_ALL_INSTITUTE = "SELECT * FROM `tuition` WHERE 1";
    private static final String SELECT_ONE_INSTITUTE = "SELECT * FROM `tuition` WHERE tuitionID=?";
        private static final String UPDATE_INSTITUTE_SQL = "update tuition set tuitionName=?,tuitionOverview=?,tuitionLocation=?,tuitionPhoneNo=?,tuitionAddress=?,tuitionSpecialities=? where tuitionID=?";

    
    public TuitionDAO(){}
    
    protected Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
    
    public void insertTuition(Tuition tuition) throws SQLException {
        System.out.println(INSERT_TUITION_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(INSERT_TUITION_SQL);
            
            PS.setString(1, tuition.getTuitionName());
            PS.setString(2, tuition.getTuitionOverview());
            PS.setString(3, tuition.getTuitionLocation());
            PS.setString(4, tuition.getTuitionPhoneNo());
            PS.setString(5, tuition.getTuitionAddress());
            PS.setString(6, tuition.getTuitionSpecialities());
            PS.executeUpdate();
            System.out.println(PS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public Tuition getTuitionID() {
        Tuition tuitionID = new Tuition();

        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(GET_LAST_TUITIONID_SQL);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                tuitionID.setTuitionID(rs.getInt("tuitionID"));
                

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tuitionID;
    }
    
    public List<Tuition> retrieveAllInstitute() {
        List<Tuition> list = new ArrayList<Tuition>();

        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_ALL_INSTITUTE);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Tuition tuition = new Tuition();
                
                tuition.setTuitionID(rs.getInt("tuitionID"));
                tuition.setTuitionName(rs.getString("tuitionName"));
                tuition.setTuitionOverview(rs.getString("tuitionOverview"));
                tuition.setTuitionLocation(rs.getString("tuitionLocation"));
                tuition.setTuitionPhoneNo(rs.getString("tuitionPhoneNo"));
                tuition.setTuitionAddress(rs.getString("tuitionAddress"));
                tuition.setTuitionSpecialities(rs.getString("tuitionSpecialities"));
                
                
                
                list.add(tuition);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public Tuition retrieveOneTuition(int id) {
        Tuition tuition = new Tuition();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_ONE_INSTITUTE);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                tuition.setTuitionID(rs.getInt("tuitionID"));
                tuition.setTuitionName(rs.getString("tuitionName"));
                tuition.setTuitionOverview(rs.getString("tuitionOverview"));
                tuition.setTuitionLocation(rs.getString("tuitionLocation"));
                tuition.setTuitionPhoneNo(rs.getString("tuitionPhoneNo"));
                tuition.setTuitionAddress(rs.getString("tuitionAddress"));
                tuition.setTuitionSpecialities(rs.getString("tuitionSpecialities"));
                

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tuition;
    }
    public boolean updateTuition(Tuition tuition) {
        boolean rowUpdate = false;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(UPDATE_INSTITUTE_SQL);

            PS.setString(1, tuition.getTuitionName());
            PS.setString(2, tuition.getTuitionOverview());
            PS.setString(3, tuition.getTuitionLocation());
            PS.setString(4, tuition.getTuitionPhoneNo());
            PS.setString(5, tuition.getTuitionAddress());
            PS.setString(6, tuition.getTuitionSpecialities());
            PS.setInt(7, tuition.getTuitionID());
            
            
            
            rowUpdate = PS.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdate;
    }
}
