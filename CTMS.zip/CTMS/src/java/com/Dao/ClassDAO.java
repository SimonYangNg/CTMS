package com.Dao;

import com.Model.Classes;
import com.Model.Tutor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClassDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/ctms";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_TUITION_CLASS_SQL = "INSERT INTO `class` (`classID`, `courseID`, `tuitionID`, `tutorID`, `totalStudent`, `availability`, `duration`, `startTime`, `endTime`, `days`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
//    private static final String INSERT_TUITION_TUTOR_SQL = "INSERT INTO `tutor` (`tutorID`, `tutorName`, `tutorGender`, `tutorDOB`, `tutorQualification`, `tutorExperience`, `tutorAddress`, `tutorLocation`, `tutorPhone`, `tutorEmail`, `tutorPassword`, `tutorNoOfYearTeach`) VALUES (NULL, ?, ?, ?, ?, ?, NULL, NULL, ?, ?, NULL, ?);";
//
//    private static final String LOGIN_VALIDATION = "Select * from tutor where tutorEmail=? and tutorPassword=? ";
    private static final String SELECT_TUITION_CLASS_BY_ID = "SELECT cl.classID, cl.courseID, cl.tutorID, cl.tuitionID, cl.totalStudent, cl.availability, cl.duration, cl.startTime, cl.endTime, cl.days, co.courseName, t.tutorName FROM `class` cl JOIN course co USING (courseID) JOIN tutor t USING (tutorID) where classID = ?;";
    private static final String UPDATE_TUITION_CLASS_SQL = "UPDATE `class` SET `courseID`=?,`tutorID`=?,`totalStudent`=?,`availability`=?,`duration`=?,`startTime`=?,`endTime`=?,`days`=? WHERE `classID`=?;";
    private static final String LIST_CLASS_BY_TUITIONID = "SELECT cl.classID, cl.courseID, cl.tutorID, cl.tuitionID, cl.totalStudent, cl.availability, cl.duration, cl.startTime, cl.endTime, cl.days, co.courseName, t.tutorName\n"
            + "FROM `class` cl  JOIN course co USING (courseID) JOIN tutor t USING (tutorID)\n"
            + "where tuitionID = ?";
    private static final String LIST_CLASS_BY_TUITIONID_COURSEID = "SELECT cl.classID, cl.courseID, cl.tutorID, cl.tuitionID, cl.totalStudent, cl.availability, cl.duration, cl.startTime, cl.endTime, cl.days, co.courseName, t.tutorName\n"
            + "FROM `class` cl  JOIN course co USING (courseID) JOIN tutor t USING (tutorID)\n"
            + "where tuitionID = ? and courseID = ?";
            
    private static final String DELETE_TUTION_CLASS = "DELETE FROM `class` WHERE `class`.`classID` = ?";
//    private static final String INSERT_TUTOR_JOINDATE="INSERT INTO `tuition_tutor` (`tuitionID`, `tutorID`, `joinDate`) VALUES (?, ?, ?)";

    public ClassDAO() {
    }

    protected Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public List<Classes> listTuitionClass(int tuitionID) {
        List<Classes> classes = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(LIST_CLASS_BY_TUITIONID);
            ps.setInt(1, tuitionID);
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int classID = rs.getInt("cl.classID");
                int courseID = rs.getInt("cl.courseID");
                int tutorID = rs.getInt("cl.tutorID");
                int totalStudent = rs.getInt("cl.totalStudent");
                String availability = rs.getString("cl.availability");
                int duration = rs.getInt("cl.duration");
                String startTime = rs.getString("cl.startTime");
                String endTime = rs.getString("cl.endTime");
                String days = rs.getString("cl.days");
                String courseName = rs.getString("co.courseName");
                String tutorName = rs.getString("t.tutorName");

                classes.add(new Classes(classID, courseID, courseName, tuitionID, tutorID, tutorName, totalStudent, availability, duration, startTime, endTime, days));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classes;
    }
    public List<Classes> listTuitionCourseClass(int tuitionID,int courseID) {
        List<Classes> classes = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(LIST_CLASS_BY_TUITIONID_COURSEID);
            ps.setInt(1, tuitionID);
            ps.setInt(2, courseID);
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int classID = rs.getInt("cl.classID");
                
                int tutorID = rs.getInt("cl.tutorID");
                int totalStudent = rs.getInt("cl.totalStudent");
                String availability = rs.getString("cl.availability");
                int duration = rs.getInt("cl.duration");
                String startTime = rs.getString("cl.startTime");
                String endTime = rs.getString("cl.endTime");
                String days = rs.getString("cl.days");
                String courseName = rs.getString("co.courseName");
                String tutorName = rs.getString("t.tutorName");

                classes.add(new Classes(classID, courseID, courseName, tuitionID, tutorID, tutorName, totalStudent, availability, duration, startTime, endTime, days));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return classes;
    }

    public void insertTuitionClass(Classes classes) throws SQLException {
        System.out.println(INSERT_TUITION_CLASS_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(INSERT_TUITION_CLASS_SQL);

            PS.setInt(1, classes.getCourseID());
            PS.setInt(2, classes.getTuitionID());
            PS.setInt(3, classes.getTutorID());
            PS.setInt(4, classes.getTotalStudent());
            PS.setString(5, classes.getAvailability());
            PS.setInt(6, classes.getDuration());
            PS.setString(7, classes.getStartTime());
            PS.setString(8, classes.getEndTime());
            PS.setString(9, classes.getDays());

            PS.executeUpdate();
            System.out.println(PS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean deleteTuitionClass(int classID) throws SQLException {
        boolean rowDeleted = false;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(DELETE_TUTION_CLASS);
            ps.setInt(1, classID);
            
            rowDeleted = ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }
    public Classes selectOneTuitionClass(int id) {
        Classes classes = new Classes();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_TUITION_CLASS_BY_ID);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                classes.setClassID(rs.getInt("classID"));
                classes.setCourseID(rs.getInt("courseID"));
                classes.setTutorID(rs.getInt("tutorID"));
                classes.setTuitionID(rs.getInt("tuitionID"));
                classes.setTotalStudent(rs.getInt("totalStudent"));
                classes.setAvailability(rs.getString("availability"));
                classes.setDuration(rs.getInt("duration"));
                classes.setStartTime(rs.getString("startTime"));
                classes.setEndTime(rs.getString("endTime")); 
                classes.setDays(rs.getString("days"));
                classes.setCourseName(rs.getString("courseName"));
                classes.setTutorName(rs.getString("tutorName"));
                

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return classes;
    }
    
        public boolean updateTuitionClass(Classes classes) {
        boolean rowUpdate = false;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(UPDATE_TUITION_CLASS_SQL);
            PS.setInt(1, classes.getCourseID());
            PS.setInt(2, classes.getTutorID());
            PS.setInt(3, classes.getTotalStudent());
            PS.setString(4, classes.getAvailability());
            PS.setInt(5, classes.getDuration());
            PS.setString(6, classes.getStartTime());
            PS.setString(7, classes.getEndTime());
            PS.setString(8, classes.getDays());
            PS.setInt(9, classes.getClassID());
            
            
            
            rowUpdate = PS.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdate;
    }
 
//    
//    public int  retrieveLatestTutorID() {
//        int tutorID = 0;
//
//        try {
//            Connection con = getConnection();
//            PreparedStatement ps = con.prepareStatement(GET_LATEST_TUTORID);
//
//            ResultSet rs = ps.executeQuery();
//
//            while (rs.next()) {
//                tutorID = rs.getInt("tutorID");
//                
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return tutorID;
//    }
//    
//    public void insertTutionTutor(Tutor tutor) throws SQLException {
//        System.out.println(INSERT_TUITION_TUTOR_SQL);
//        try {
//            Connection con = getConnection();
//            PreparedStatement PS = con.prepareStatement(INSERT_TUITION_TUTOR_SQL);
//
//            PS.setString(1, tutor.getTutorName());
//            PS.setString(2, tutor.getTutorGender());
//            PS.setString(3, tutor.getTutorDOB());
//            PS.setString(4, tutor.getTutorQualification());
//            PS.setString(5, tutor.getTutorExperience());
//            PS.setString(6, tutor.getTutorPhone());
//            PS.setString(7, tutor.getTutorEmail());
//            PS.setInt(8, tutor.getTutorNoOfYearTeach());
//            PS.executeUpdate();
//            System.out.println(PS);
//
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//
//    public Tutor tutorLogin(String username, String password) {
//        Tutor tutor = null;
//        try {
//            Connection con = getConnection();
//            PreparedStatement PS = con.prepareStatement(LOGIN_VALIDATION);
//            PS.setString(1, username);
//            PS.setString(2, password);
//
//            ResultSet rs = PS.executeQuery();
//            if (rs.next()) {
//                tutor = new Tutor();
//                tutor.setTutorID(rs.getInt("tutorID"));
//                tutor.setTutorName(rs.getString("tutorName"));
//                tutor.setTutorGender(rs.getString("tutorGender"));
//                tutor.setTutorDOB(rs.getString("tutorDOB"));
//                tutor.setTutorQualification(rs.getString("tutorQualification"));
//                tutor.setTutorExperience(rs.getString("tutorExperience"));
//                tutor.setTutorAddress(rs.getString("tutorAddress"));
//                tutor.setTutorLocation(rs.getString("tutorLocation"));
//                tutor.setTutorPhone(rs.getString("tutorPhone"));
//                tutor.setTutorEmail(rs.getString("tutorEmail"));
//                tutor.setTutorPassword(rs.getString("tutorPassword"));
//                tutor.setTutorNoOfYearTeach(rs.getInt("tutorNoOfYearTeach"));
//
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return tutor;
//    }
//

//    

    }
