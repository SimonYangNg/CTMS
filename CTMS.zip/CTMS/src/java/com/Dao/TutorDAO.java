package com.Dao;


import com.Model.Tutor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TutorDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/ctms";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_TUTOR_SQL = "INSERT INTO `tutor` (`tutorID`, `tutorName`, `tutorGender`, `tutorDOB`, `tutorQualification`, `tutorExperience`, `tutorAddress`, `tutorLocation`, `tutorPhone`, `tutorEmail`, `tutorPassword`, `tutorNoOfYearTeach`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
    private static final String INSERT_TUITION_TUTOR_SQL = "INSERT INTO `tutor` (`tutorID`, `tutorName`, `tutorGender`, `tutorDOB`, `tutorQualification`, `tutorExperience`, `tutorAddress`, `tutorLocation`, `tutorPhone`, `tutorEmail`, `tutorPassword`, `tutorNoOfYearTeach`) VALUES (NULL, ?, ?, ?, ?, ?, NULL, NULL, ?, ?, NULL, ?);";

    private static final String LOGIN_VALIDATION = "Select * from tutor where tutorEmail=? and tutorPassword=? ";
    private static final String SELECT_TUTOR_BY_ID = "select * from tutor where tutorID=?";
    private static final String UPDATE_TUTORPROFILE_SQL = "update tutor set tutorName=?,tutorGender=?,tutorDOB=?,tutorQualification=?,tutorExperience=?,tutorAddress=?,tutorLocation=?,tutorPhone=?,tutorEmail=?,tutorPassword=?,tutorNoOfYearTeach=? where tutorID=?";
    private static final String LIST_TUTOR_BY_TUITIONID = "SELECT * FROM `tuition_tutor`tt JOIN tutor t USING (tutorID) WHERE tuitionID=?";
    private static final String LIST_TUTOR = "SELECT * FROM `tutor` WHERE `tutorAddress`is not null;";
    private static final String GET_LATEST_TUTORID = "Select * from tutor where tutorID = (select max(tutorID) from tutor)";
    private static final String INSERT_TUTOR_JOINDATE="INSERT INTO `tuition_tutor` (`tuitionID`, `tutorID`, `joinDate`) VALUES (?, ?, ?)";
    private static final String UPDATE_TUITION_TUTORPROFILE_SQL = "update tutor set tutorName=?,tutorGender=?,tutorDOB=?,tutorQualification=?,tutorExperience=?,tutorPhone=?,tutorEmail=?,tutorNoOfYearTeach=? where tutorID=?";


    public TutorDAO() {
    }

    protected Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
    public List<Tutor> listTuitionTutor(int tuitionID) {
        List<Tutor> tutors = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(LIST_TUTOR_BY_TUITIONID);
            ps.setInt(1, tuitionID);
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int tutorID = rs.getInt("tutorID");
                String tutorName = rs.getString("tutorName");
                String tutorGender = rs.getString("tutorGender");
                String tutorDOB = rs.getString("tutorDOB");
                String tutorQualification = rs.getString("tutorQualification");
                String tutorExperience = rs.getString("tutorExperience");
                String tutorPhone = rs.getString("tutorPhone");
                String tutorEmail = rs.getString("tutorEmail");
                int tutorNoOfYearTeach = rs.getInt("tutorNoOfYearTeach");
                
                tutors.add(new Tutor(tutorID, tutorName, tutorGender, tutorDOB,tutorQualification,tutorExperience,tutorPhone,tutorEmail,tutorNoOfYearTeach));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tutors;
    }
    public List<Tutor> retrieveAllTutor() {
        List<Tutor> tutors = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(LIST_TUTOR);
            
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                int tutorID = rs.getInt("tutorID");
                String tutorName = rs.getString("tutorName");
                String tutorGender = rs.getString("tutorGender");
                String tutorDOB = rs.getString("tutorDOB");
                String tutorQualification = rs.getString("tutorQualification");
                String tutorExperience = rs.getString("tutorExperience");
                String tutorAddress = rs.getString("tutorAddress");
                String tutorLocation = rs.getString("tutorLocation");
                String tutorPhone = rs.getString("tutorPhone");
                String tutorEmail = rs.getString("tutorEmail");
                int tutorNoOfYearTeach = rs.getInt("tutorNoOfYearTeach");
                
                tutors.add(new Tutor(tutorID, tutorName, tutorGender, tutorDOB,tutorQualification,tutorExperience,tutorAddress,tutorPhone,tutorLocation,tutorEmail,tutorNoOfYearTeach));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tutors;
    }
    public void insertTuitionTutorJoinDate(int tuitionID,int tutorID, String date) throws SQLException {
        System.out.println(INSERT_TUTOR_JOINDATE);
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(INSERT_TUTOR_JOINDATE);
           
            PS.setInt(1, tuitionID);
            PS.setInt(2, tutorID);
            PS.setString(3, date);
            
            PS.executeUpdate();
            System.out.println(PS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    
    public int  retrieveLatestTutorID() {
        int tutorID = 0;

        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(GET_LATEST_TUTORID);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                tutorID = rs.getInt("tutorID");
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tutorID;
    }
    
    public void insertTutionTutor(Tutor tutor) throws SQLException {
        System.out.println(INSERT_TUITION_TUTOR_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(INSERT_TUITION_TUTOR_SQL);

            PS.setString(1, tutor.getTutorName());
            PS.setString(2, tutor.getTutorGender());
            PS.setString(3, tutor.getTutorDOB());
            PS.setString(4, tutor.getTutorQualification());
            PS.setString(5, tutor.getTutorExperience());
            PS.setString(6, tutor.getTutorPhone());
            PS.setString(7, tutor.getTutorEmail());
            PS.setInt(8, tutor.getTutorNoOfYearTeach());
            PS.executeUpdate();
            System.out.println(PS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insertTutor(Tutor tutor) throws SQLException {
        System.out.println(INSERT_TUTOR_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(INSERT_TUTOR_SQL);

            PS.setString(1, tutor.getTutorName());
            PS.setString(2, tutor.getTutorGender());
            PS.setString(3, tutor.getTutorDOB());
            PS.setString(4, tutor.getTutorQualification());
            PS.setString(5, tutor.getTutorExperience());
            PS.setString(6, tutor.getTutorAddress());
            PS.setString(7, tutor.getTutorLocation());
            PS.setString(8, tutor.getTutorPhone());
            PS.setString(9, tutor.getTutorEmail());
            PS.setString(10, tutor.getTutorPassword());
            PS.setInt(11, tutor.getTutorNoOfYearTeach());
            PS.executeUpdate();
            System.out.println(PS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public Tutor tutorLogin(String username, String password) {
        Tutor tutor = null;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(LOGIN_VALIDATION);
            PS.setString(1, username);
            PS.setString(2, password);

            ResultSet rs = PS.executeQuery();
            if (rs.next()) {
                tutor = new Tutor();
                tutor.setTutorID(rs.getInt("tutorID"));
                tutor.setTutorName(rs.getString("tutorName"));
                tutor.setTutorGender(rs.getString("tutorGender"));
                tutor.setTutorDOB(rs.getString("tutorDOB"));
                tutor.setTutorQualification(rs.getString("tutorQualification"));
                tutor.setTutorExperience(rs.getString("tutorExperience"));
                tutor.setTutorAddress(rs.getString("tutorAddress"));
                tutor.setTutorLocation(rs.getString("tutorLocation"));
                tutor.setTutorPhone(rs.getString("tutorPhone"));
                tutor.setTutorEmail(rs.getString("tutorEmail"));
                tutor.setTutorPassword(rs.getString("tutorPassword"));
                tutor.setTutorNoOfYearTeach(rs.getInt("tutorNoOfYearTeach"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tutor;
    }

    public Tutor retrieveOneTutor(int id) {
        Tutor tutor = new Tutor();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_TUTOR_BY_ID);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                tutor.setTutorID(rs.getInt("tutorID"));
                tutor.setTutorName(rs.getString("tutorName"));
                tutor.setTutorGender(rs.getString("tutorGender"));
                tutor.setTutorDOB(rs.getString("tutorDOB"));
                tutor.setTutorQualification(rs.getString("tutorQualification"));
                tutor.setTutorExperience(rs.getString("tutorExperience"));
                tutor.setTutorAddress(rs.getString("tutorAddress"));
                tutor.setTutorLocation(rs.getString("tutorLocation"));
                tutor.setTutorPhone(rs.getString("tutorPhone"));
                tutor.setTutorEmail(rs.getString("tutorEmail"));
                tutor.setTutorPassword(rs.getString("tutorPassword"));
                tutor.setTutorNoOfYearTeach(rs.getInt("tutorNoOfYearTeach"));
                

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tutor;
    }
    
//    public Tutor retrieveOneTutor(int id) {
//        Tutor tutor = new Tutor();
//        try {
//            Connection con = getConnection();
//            PreparedStatement ps = con.prepareStatement(SELECT_TUTOR_BY_ID);
//            ps.setInt(1, id);
//            ResultSet rs = ps.executeQuery();
//
//            while (rs.next()) {
//                tutor.setTutorID(rs.getInt("tutorID"));
//                tutor.setTutorName(rs.getString("tutorName"));
//                tutor.setTutorGender(rs.getString("tutorGender"));
//                tutor.setTutorDOB(rs.getString("tutorDOB"));
//                tutor.setTutorQualification(rs.getString("tutorQualification"));
//                tutor.setTutorExperience(rs.getString("tutorExperience"));
//                tutor.setTutorAddress(rs.getString("tutorAddress"));
//                tutor.setTutorLocation(rs.getString("tutorLocation"));
//                tutor.setTutorPhone(rs.getString("tutorPhone"));
//                tutor.setTutorEmail(rs.getString("tutorEmail"));
//                tutor.setTutorPassword(rs.getString("tutorPassword"));
//                tutor.setTutorNoOfYearTeach(rs.getInt("tutorNoOfYearTeach"));
//                
//
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return tutor;
//    }
    
    public boolean updateTutor(Tutor tutor) {
        boolean rowUpdate = false;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(UPDATE_TUTORPROFILE_SQL);

            PS.setString(1, tutor.getTutorName());
            PS.setString(2, tutor.getTutorGender());
            PS.setString(3, tutor.getTutorDOB());
            PS.setString(4, tutor.getTutorQualification());
            PS.setString(5, tutor.getTutorExperience());
            PS.setString(6, tutor.getTutorAddress());
            PS.setString(7, tutor.getTutorLocation());
            PS.setString(8, tutor.getTutorPhone());
            PS.setString(9, tutor.getTutorEmail());
            PS.setString(10, tutor.getTutorPassword());
            PS.setInt(11, tutor.getTutorNoOfYearTeach());
            PS.setInt(12, tutor.getTutorID());
            
            
            rowUpdate = PS.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdate;
    }
    public boolean updateTuitionTutor(Tutor tutor) {
        boolean rowUpdate = false;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(UPDATE_TUITION_TUTORPROFILE_SQL);

            PS.setString(1, tutor.getTutorName());
            PS.setString(2, tutor.getTutorGender());
            PS.setString(3, tutor.getTutorDOB());
            PS.setString(4, tutor.getTutorQualification());
            PS.setString(5, tutor.getTutorExperience());
            PS.setString(6, tutor.getTutorPhone());
            PS.setString(7, tutor.getTutorEmail());
            PS.setInt(8, tutor.getTutorNoOfYearTeach());
            PS.setInt(9, tutor.getTutorID());
            
            rowUpdate = PS.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdate;
    }
    
    
}
