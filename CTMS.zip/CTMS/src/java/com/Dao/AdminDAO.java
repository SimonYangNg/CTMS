
package com.Dao;

import com.Model.Admin;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDAO {
    private String jdbcURL = "jdbc:mysql://localhost:3306/ctms";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";
    
    
    
    private static final String INSERT_ADMIN_SQL="INSERT INTO `admin` (`adminID`, `adminName`, `adminPassword`, `adminPhoneNo`, `adminEmail`, `tuitionID`) VALUES (NULL, ?, ?, ?, ?, ?)";
    private static final String LOGIN_VALIDATION = "Select * from admin where adminEmail=? and adminPassword=? ";
    private static final String SELECT_ADMIN_BY_ID = "select * from admin where adminID=?";
    private static final String UPDATE_ADMINPROFILE_SQL = "update admin set adminName=?,adminPassword=?,adminPhoneNo=?,adminEmail=? where adminID=?";

    public AdminDAO(){}
    
    protected Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }
    public void insertAdmin(Admin admin) throws SQLException {
        System.out.println(INSERT_ADMIN_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(INSERT_ADMIN_SQL);
           
            PS.setString(1, admin.getAdminName());
            PS.setString(2, admin.getAdminPassword());
            PS.setString(3, admin.getAdminPhoneNo());
            PS.setString(4, admin.getAdminEmail());
            PS.setInt(5, admin.getTuitionID());
            PS.executeUpdate();
            System.out.println(PS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
     

    public Admin adminLogin(String username, String password) {
        Admin admin = null;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(LOGIN_VALIDATION);
            PS.setString(1, username);
            PS.setString(2, password);

            ResultSet rs = PS.executeQuery();
            if (rs.next()) {
                admin = new Admin();
                admin.setAdminID(rs.getInt("adminID"));
                admin.setAdminName(rs.getString("adminName"));
                admin.setAdminPassword(rs.getString("adminPassword"));
                admin.setAdminPhoneNo(rs.getString("adminPhoneNo"));
                admin.setAdminEmail(rs.getString("adminEmail"));
                admin.setTuitionID(rs.getInt("tuitionID"));
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return admin;
    }
    public Admin retrieveOneAdmin(int id) {
        Admin admin = new Admin();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_ADMIN_BY_ID);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
               admin.setAdminID(rs.getInt("adminID"));
                admin.setAdminName(rs.getString("adminName"));
                admin.setAdminPassword(rs.getString("adminPassword"));
                admin.setAdminPhoneNo(rs.getString("adminPhoneNo"));
                admin.setAdminEmail(rs.getString("adminEmail"));
                admin.setTuitionID(rs.getInt("tuitionID"));
                
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return admin;
    }
    public boolean updateAdmin(Admin admin) {
        boolean rowUpdate = false;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(UPDATE_ADMINPROFILE_SQL);

            PS.setString(1, admin.getAdminName());
            PS.setString(2, admin.getAdminPassword());
            PS.setString(3, admin.getAdminPhoneNo());
            PS.setString(4, admin.getAdminEmail());
            PS.setInt(5, admin.getAdminID());
            
            
            rowUpdate = PS.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdate;
    }
}
