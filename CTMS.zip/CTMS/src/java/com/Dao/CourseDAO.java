package com.Dao;

import com.Model.Courses;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/ctms";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_TUITION_COURSE_SQL = "INSERT INTO `tuition_tutor_course` (`courseID`, `tuitionID`, `tutorID`, `courseDescription`,`coursePrice`) VALUES (?, ?, 0, ?, ?)"; 
    private static final String INSERT_PRIVATE_TUTOR_COURSE_SQL = "INSERT INTO `tuition_tutor_course` (`courseID`, `tuitionID`, `tutorID`, `courseDescription`,`coursePrice`) VALUES (?, 0, ?, ?, ?)"; 
    private static final String INSERT_COURSE_SQL = "INSERT INTO `course` (`courseID`, `courseName`) VALUES (NULL, ?)";
    private static final String SELECT_ALL_TUITION_COURSE = "SELECT * \n"
            + "FROM `tuition_tutor_course`\n"
            + "JOIN course USING (courseID)\n"
            + "WHERE tuitionID=?";
    private static final String SELECT_ALL_PRIVATE_TUTOR_COURSE = "SELECT * \n"
            + "FROM `tuition_tutor_course`\n"
            + "JOIN course USING (courseID)\n"
            + "WHERE tutorID=?";
    private static final String SELECT_ALL_COURSE ="select * from course";
    private static final String GET_LAST_COURSEID_SQL = "Select courseID from course where courseID = (select max(courseID) from course)";
    private static final String SELECT_TUITION_COURSE_BY_ID = "select * from tuition_tutor_course join course using (courseID) where courseID=? and tuitionID=?";
    private static final String DELETE_TUITION_COURSE_SQL = "delete from tuition_tutor_course where  courseID= ? and tuitionID=?";
    private static final String UPDATE_TUITION_COURSE_SQL = "update tuition_tutor_course set courseDescription = ?, coursePrice = ? where courseID = ? and tuitionID=?";

    public CourseDAO() {
    }

    protected Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public void insertNewCourse(String newCourse) throws SQLException{
        System.out.println(INSERT_COURSE_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(INSERT_COURSE_SQL);
            ps.setString(1, newCourse);
            
            ps.executeUpdate();
            System.out.println(ps);
        } catch (Exception e) {
            e.printStackTrace();
        }
    } 
    public Courses getNewCourseID() {
        Courses courseID = new Courses();

        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(GET_LAST_COURSEID_SQL);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                courseID.setCourseID(rs.getInt("courseID"));
                

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return courseID;
    }
    public void insertCourse(Courses course) throws SQLException{
        System.out.println(INSERT_TUITION_COURSE_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(INSERT_TUITION_COURSE_SQL);
            ps.setInt(1, course.getCourseID());
            ps.setInt(2, course.getTuitionID());
            ps.setString(3, course.getCourseDescription());
            ps.setDouble(4, course.getCoursePrice());
            ps.executeUpdate();
            System.out.println(ps);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void insertPrivateTutorCourse(Courses course) throws SQLException{
        System.out.println(INSERT_PRIVATE_TUTOR_COURSE_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(INSERT_PRIVATE_TUTOR_COURSE_SQL);
            ps.setInt(1, course.getCourseID());
            ps.setInt(2, course.getTutorID());
            ps.setString(3, course.getCourseDescription());
            ps.setDouble(4, course.getCoursePrice());
            ps.executeUpdate();
            System.out.println(ps);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public List<Courses> selectTuitionCourse(int tuitionID) {
        List<Courses> courses = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_ALL_TUITION_COURSE);
            ps.setInt(1, tuitionID);
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int courseID = rs.getInt("courseID");
                
                String courseDescription = rs.getString("courseDescription");
                Double coursePrice = rs.getDouble("coursePrice");
                String courseName = rs.getString("courseName");
                courses.add(new Courses(courseID, courseName, tuitionID, courseDescription,coursePrice));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }

    public List<Courses> selectPrivateTutorCourse(int tutorID) {
        List<Courses> courses = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_ALL_PRIVATE_TUTOR_COURSE);
            ps.setInt(1, tutorID);
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int courseID = rs.getInt("courseID");
                
                String courseDescription = rs.getString("courseDescription");
                Double coursePrice = rs.getDouble("coursePrice");
                String courseName = rs.getString("courseName");
                courses.add(new Courses(courseID, courseName,courseDescription,tutorID,coursePrice));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }
    public Courses selectOneTuitionCourse(int courseid,int tuitionid){
        Courses course = null;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_TUITION_COURSE_BY_ID);
            ps.setInt(1, courseid);
            ps.setInt(2, tuitionid);
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                String courseName = rs.getString("courseName");
                String courseDescription = rs.getString("courseDescription");
                Double coursePrice = rs.getDouble("coursePrice");
                
                course =  new Courses(courseid, courseName, tuitionid, courseDescription,coursePrice);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return course;
    }
    public List<Courses> getAllCourse() {
        List<Courses> courses = new ArrayList<>();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_ALL_COURSE);
            System.out.println(ps);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int courseID = rs.getInt("courseID");
                String courseName = rs.getString("courseName");
                courses.add(new Courses(courseID, courseName));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return courses;
    }
    
    public boolean updateTuitionCourse(Courses course) {
        boolean rowUpdate = false;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(UPDATE_TUITION_COURSE_SQL);

            PS.setString(1, course.getCourseDescription());
            PS.setDouble(2, course.getCoursePrice());
            PS.setInt(3, course.getCourseID());
            PS.setInt(4, course.getTuitionID());
            
            rowUpdate = PS.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdate;
    }
    public boolean deleteTuitionCourse(int courseID, int tuitionID) throws SQLException{
        boolean rowDeleted = false;
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(DELETE_TUITION_COURSE_SQL);
            ps.setInt(1, courseID);
            ps.setInt(2, tuitionID);
            rowDeleted = ps.executeUpdate()>0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rowDeleted;
    }
}
