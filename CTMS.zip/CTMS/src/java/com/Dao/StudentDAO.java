package com.Dao;

import com.Model.Student;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StudentDAO {

    private String jdbcURL = "jdbc:mysql://localhost:3306/ctms";
    private String jdbcUsername = "root";
    private String jdbcPassword = "";

    private static final String INSERT_STUDENT_SQL = "INSERT INTO `student` (`studentID`, `studentName`, `studentIC`, `studentSchool`, `studentPhoneNo`, `studentEmail`, `studentPassword`, `studentAddress`) VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)";
    private static final String LOGIN_VALIDATION = "Select * from student where studentEmail=? and studentPassword=? ";
    private static final String SELECT_STUDENT_BY_ID = "select * from student where studentID=?";
    private static final String UPDATE_STUDENTPROFILE_SQL = "update student set studentName=?,studentIC=?,studentSchool=?,studentPassword=?,studentPhoneNo=?,studentEmail=?,studentAddress=? where studentID=?";

    public StudentDAO() {
    }

    protected Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public void insertStudent(Student student) throws SQLException {
        System.out.println(INSERT_STUDENT_SQL);
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(INSERT_STUDENT_SQL);

            PS.setString(1, student.getStudentName());
            PS.setString(2, student.getStudentIC());
            PS.setString(3, student.getStudentSchool());
            PS.setString(4, student.getStudentPhoneNo());
            PS.setString(5, student.getStudentEmail());
            PS.setString(6, student.getStudentPassword());
            PS.setString(7, student.getStudentAddress());
            PS.executeUpdate();
            System.out.println(PS);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

        public Student studentLogin(String username, String password) {
        Student student = null;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(LOGIN_VALIDATION);
            PS.setString(1, username);
            PS.setString(2, password);

            ResultSet rs = PS.executeQuery();
            if (rs.next()) {
                student = new Student();
                student.setStudentID(rs.getInt("studentID"));
                student.setStudentName(rs.getString("studentName"));
                student.setStudentPassword(rs.getString("studentPassword"));
                student.setStudentPhoneNo(rs.getString("studentPhoneNo"));
                student.setStudentEmail(rs.getString("studentEmail"));
                student.setStudentIC(rs.getString("studentIC"));
                student.setStudentAddress(rs.getString("studentAddress"));
                student.setStudentSchool(rs.getString("studentSchool"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return student;
    }

    public Student retrieveOneStudent(int id) {
        Student student = new Student();
        try {
            Connection con = getConnection();
            PreparedStatement ps = con.prepareStatement(SELECT_STUDENT_BY_ID);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                student.setStudentID(rs.getInt("studentID"));
                student.setStudentName(rs.getString("studentName"));
                student.setStudentPassword(rs.getString("studentPassword"));
                student.setStudentPhoneNo(rs.getString("studentPhoneNo"));
                student.setStudentEmail(rs.getString("studentEmail"));
                student.setStudentIC(rs.getString("studentIC"));
                student.setStudentAddress(rs.getString("studentAddress"));
                student.setStudentSchool(rs.getString("studentSchool"));

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return student;
    }
    public boolean updateStudent(Student student) {
        boolean rowUpdate = false;
        try {
            Connection con = getConnection();
            PreparedStatement PS = con.prepareStatement(UPDATE_STUDENTPROFILE_SQL);

            PS.setString(1, student.getStudentName());
            PS.setString(2, student.getStudentIC());
            PS.setString(3, student.getStudentSchool());
            PS.setString(4, student.getStudentPassword());
            PS.setString(5, student.getStudentPhoneNo());
            PS.setString(6, student.getStudentEmail());
            PS.setString(7, student.getStudentAddress());
            PS.setInt(8, student.getStudentID());
            
            
            rowUpdate = PS.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rowUpdate;
    }
}
